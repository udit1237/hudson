
using System;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.Collections;
using System.ComponentModel;
using System.Data;

namespace WindowsApplication4
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		/// <summary>
		/// 
		/// </summary>
		private System.Windows.Forms.PictureBox pictureBox1;
		private Button button1;
		private int tempX = 0;
		private int tempY = 40;
		private int xDirection = 1;
		private int yDirection = 1;
//		public event EventHandler Click;
//		private int y;
		
		public Form1()
		{
			button1 = new Button();
			button1.Location = new Point(0,0);
			button1.Click += new EventHandler(this.Button_Clicked);
			button1.Text = "Start";
			Controls.Add(button1);
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			
		}

		private void Button_Clicked(object sender, EventArgs e)
		{
			simulationLoop();	
		}

		protected void simulationLoop()
		{
			pictureBox1.Visible = true;
			pictureBox1.Location = new Point(tempX,tempY);
			this.Refresh();
			//Console.WriteLine("about to loop");
			for(int i = 0; i< 250;i++)
			{
				for(int j=0;j<10000;j++)
				{
					for(int k=0;k<1000;k++)
					{
					}
				}
				if(xDirection == 1)
				{
					if(tempX > 100)
					{
						tempX = tempX - 5;
						xDirection = -1;
					}
					if(tempX <= 100)
					{
						tempX = tempX + 5;
					}
				}
				else if(xDirection == -1)
				{
					if(tempX < 0)
					{
						tempX = tempX + 5;
						xDirection = 1;
					}
					if(tempX >= 0)
					{
						tempX = tempX - 5;
					}
				}
				if(yDirection == 1)
				{
					if(tempY > 100)
					{
						tempY = tempY - 5;
						yDirection = -1;
					}
					if(tempY <= 100)
					{
						tempY = tempY + 5;
					}
				}
				else if(yDirection == -1)
				{
					if(tempY < 0)
					{
						tempY = tempY + 5;
						yDirection = 1;
					}
					if(tempY >= 0)
					{
						tempY = tempY - 5;
					}
				}
				
				//	pictureBox1.Visible = true;
				pictureBox1.Location = new Point(tempX,tempY);
				//Console.WriteLine("just set location");
				this.Refresh();
			}		
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		
		protected override void OnPaint(PaintEventArgs e)
		{
			Graphics g = e.Graphics;
			Pen blackPen = new Pen(Color.Black, 3);
			Console.WriteLine("on paint");
		}

		#region Windows Form Designer generated code
			/// <summary>
			/// Required method for Designer support - do not modify
			/// the contents of this method with the code editor.
			/// </summary>
			private void InitializeComponent()
		{
				System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
				this.pictureBox1 = new System.Windows.Forms.PictureBox();
				this.SuspendLayout();
				// 
				// pictureBox1
				// 
				this.pictureBox1.Image = ((System.Drawing.Bitmap)(resources.GetObject("pictureBox1.Image")));
				this.pictureBox1.Location = new System.Drawing.Point(24, 56);
				this.pictureBox1.Name = "pictureBox1";
				this.pictureBox1.Size = new System.Drawing.Size(24, 24);
				this.pictureBox1.TabIndex = 0;
				this.pictureBox1.TabStop = false;
				this.pictureBox1.Visible = false;
				// 
				// Form1
				// 
				this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
				this.ClientSize = new System.Drawing.Size(292, 273);
				this.Controls.AddRange(new System.Windows.Forms.Control[] {
																			  this.pictureBox1});
				this.Name = "Form1";
				this.Text = "Brickles";
				this.Load += new System.EventHandler(this.Form1_Load);
				this.ResumeLayout(false);

			}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
		
		}
	}
}
