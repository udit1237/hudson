using System;
using System.ComponentModel;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;

namespace GameDefinitions
{
	/// <summary>
	/// Summary description for StationarySprite.
	/// </summary>
	public abstract class StationarySprite:Sprite
	{
		public StationarySprite(Point p, Size s):base(p,s)
		{
			//
			// TODO: Add constructor logic here
			//
		}

		
	}
}
