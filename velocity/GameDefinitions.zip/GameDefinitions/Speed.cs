using System;

namespace GameDefinitions
{
	/// <summary>
	/// Summary description for Speed.
	/// </summary>
	public class Speed
	{
		public Speed()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public Speed(int value)
		{
				_speed = value;
		}

		public int getSpeed()
		{
			return _speed;
		}

		protected int _speed;
	}
}
