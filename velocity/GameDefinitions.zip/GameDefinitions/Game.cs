using System;

namespace GameDefinitions
{
	/// <summary>
	/// Summary description for Game.
	/// </summary>
	public class Game
	{
		public Game()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
