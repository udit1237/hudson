using System;
using System.ComponentModel;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;

namespace GameDefinitions
{
	/// <summary>
	/// Summary description for MovableSprite.
	/// </summary>
	public abstract class MovableSprite:Sprite
	{
		protected Velocity myVelocity;
		protected bool isMoving;

		/// <summary>
		/// Constructor - 
		/// </summary>
		/// <param name="p">Location</param>
		/// <param name="s">Size</param>
		public MovableSprite(Point p,Size s):base(p,s)
		{
			//
			// TODO: Add constructor logic here
			//
			startMoving();
		}

		public override void paint(PaintEventArgs e)
		{
			Graphics g = e.Graphics;
			if(this.visible)
			{
				PictureBox pb = this.getPicture();
				g.DrawImage(pb.Image,pb.Location);
				
			}
		}

		public bool moving()
		{
			return isMoving;
		}
		

		public void startMoving()
		{
			isMoving = true;
		}

		public void stopMoving()
		{
			isMoving = false;
		}

		public Speed mySpeed
		{
			get{return myVelocity.getSpeed();}
			set{myVelocity.setSpeed(value);}
		}

		public Direction myDirection
		{
			get{return myVelocity.getDirection();}
			set{myVelocity.setDirection(value);}
		}

		public void reverseX()
		{
			myVelocity.reverseX();
		}

		public void reverseY()
		{
			myVelocity.reverseY();
		}

		public virtual void move()
		{
			if(isMoving)
			{
				icon.Location = new Point(MyLocation.X+myVelocity.speedX(),MyLocation.Y+myVelocity.speedY());
				//The dumb mistake of the year
				MyLocation = new Point(MyLocation.X+myVelocity.speedX(),MyLocation.Y+myVelocity.speedY());
				//icon.Location = new Point(MyLocation.X+myVelocity.speedX(),MyLocation.Y+myVelocity.speedY());
				
			}
			
			this.setBoundingBox();
		}

		public virtual void delete()
		{
		}


	}
}
