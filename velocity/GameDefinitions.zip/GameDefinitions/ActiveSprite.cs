using System;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace GameDefinitions
{
	/// <summary>
	/// Summary description for ActiveSprite.
	/// </summary>
	public class ActiveSprite:StationarySprite
	{
		protected TimerCallback timerDelegate;
		protected System.Threading.Timer timer;
		protected AnimationEffect ae;
    
		
		public ActiveSprite(Point p,Size s):base(p,s)
		{
			//
			// TODO: Add constructor logic here
			//
			ae = new AnimationEffect();

			timerDelegate = new TimerCallback(this.animator);
			

		}

		public override void collideWith(MovableSprite ms)
		{
			timer = new System.Threading.Timer(timerDelegate, ae,1000, 1000);
    
			// Keep a handle to the timer, so it can be disposed.
			ae.tmr = timer;
		}

		public override void paint(PaintEventArgs e )
		{
			


			
		}

		public virtual void animator(object state)
		{
			AnimationEffect ae =(AnimationEffect)state;

			switch(ae.count)
			{
				case 0:Console.WriteLine("zero");
					break;
				case 1:Console.WriteLine("one");
					break;
				case 2:Console.WriteLine("two");
					ae.tmr.Dispose();
					break;
			}
			ae.count++;
		}
	}
}
