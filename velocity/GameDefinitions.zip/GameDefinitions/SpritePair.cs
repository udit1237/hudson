using System;
using System.ComponentModel;

namespace GameDefinitions
{
	/// <summary>
	/// Summary description for SpritePair.
	/// </summary>
	public class SpritePair:IComponent
	{

		public event EventHandler Disposed;

		public SpritePair(Sprite s1,Sprite s2)
		{
			first = s1;
			second = s2;
		}

		private Sprite first;
		public Sprite firstItem
		{
			get
			{
				return first;
			}
			set
			{
				first = value;
			}
		}

		private Sprite second;
		public Sprite secondItem
		{
			get
			{
				return second;
			}
			set
			{
				second = value;
			}
		}

		private ISite siteName;
		public ISite Site 
		{
			get
			{
				return siteName;
			} 
			set
			{
				siteName = value;
			}
		}

		

		/// <summary>
		/// called when the Sprite is deleted
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		public virtual void Dispose(object sender, System.EventArgs e)
		{
			
		}

		/// <summary>
		/// called when the Sprite is deleted
		/// </summary>
		public virtual void Dispose(){}
	}
}
