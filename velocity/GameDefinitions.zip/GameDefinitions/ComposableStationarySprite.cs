using System;
using System.Drawing;

namespace GameDefinitions
{
	/// <summary>
	/// Summary description for ComposableStationarySprite.
	/// </summary>
	public abstract class ComposableStationarySprite: StationarySprite
	{
		public ComposableStationarySprite(Point p, Size s):base(p,s)
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
