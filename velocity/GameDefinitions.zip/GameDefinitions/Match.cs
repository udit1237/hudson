using System;

namespace GameDefinitions
{
	/// <summary>
	/// Summary description for Match.
	/// </summary>
	public class Match
	{
		
		public Match()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
