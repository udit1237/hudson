using System;
using System.ComponentModel;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;

namespace GameDefinitions
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	public abstract class Sprite:IComponent
	{
		
		protected System.Windows.Forms.PictureBox myImage;
		protected System.Drawing.Point MyLocation;
		public event EventHandler Disposed;
		protected System.Drawing.Size size;
		protected System.Drawing.Rectangle boundingBox;
		
		protected bool visibility = false;
		protected Sprite lastCollision;

		/// <summary>
		/// This method is overridden by each Sprite to determine their behavior in a collision
		/// </summary>
		/// <param name="m">The MovableSprite that this Sprite has collided with</param>
		public abstract void collideWith(MovableSprite m);
		public abstract void paint(PaintEventArgs e);

		/// <summary>
		/// The base constructor for the Sprite hierarchy 
		/// </summary>
		/// <param name="p">Location of the Sprite</param>
		/// <param name="s">The size of the Sprite</param>
		public Sprite(Point p,Size s)
		{
			//this.Disposed += new EventHandler(this.Dispose);
			
			this.icon = new System.Windows.Forms.PictureBox();
			this.icon.Location = p;
			this.icon.Name = "Sprite";
			this.icon.Size = s;
			this.icon.TabIndex = 0;
			this.icon.TabStop = false;
			this.icon.Visible = false; 
			size = s;
			MyLocation = p;
			setBoundingBox();
			lastCollision = this;

		}
	

		/// <summary>
		/// the image of the Sprite 
		/// </summary>
		public System.Windows.Forms.PictureBox icon
		{
			get
			{
				return myImage;
			}
			set
			{
				myImage = value;
			}
		}

		/// <summary>
		/// sets the boundary around the Sprite that signifies a collision
		/// </summary>
		public void setBoundingBox()
		{
			boundingBox = new Rectangle(new Point(MyLocation.X,MyLocation.Y),new Size(size.Width,size.Height));
		}

		/// <summary>
		/// gets the icon for this Sprite
		/// </summary>
		/// <returns></returns>
		public PictureBox getPicture()
		{
			return icon;
		}

		/// <summary>
		/// return the bounding box of the Sprite
		/// </summary>
		/// <returns></returns>
		public virtual Rectangle getBoundingBox()
		{
			return this.boundingBox;
		}

		/// <summary>
		/// return the bounding box of the Sprite
		/// </summary>
		/// <returns></returns>
		public virtual Rectangle getBoundingBox(Sprite s)
		{
			if (s.getBoundingBox().IntersectsWith(this.getBoundingBox()))
			{
				return this.boundingBox;
			}
			else 
				return new Rectangle();
		}

		/// <summary>
		/// return true if the two sprites overlap
		/// </summary>
		/// <returns></returns>
		public virtual bool overLaps(Sprite s)
		{
			return s.getBoundingBox().IntersectsWith(this.getBoundingBox());
		}

		/// <summary>
		/// return true if the passed rectangle overlaps with the sprite
		/// </summary>
		/// <returns></returns>
		public virtual bool overLaps(Rectangle r)
		{
			return r.IntersectsWith(this.getBoundingBox());
		}

		/// <summary>
		/// Is the Sprite visible
		/// </summary>
		public bool visible
		{
			get
			{
				return visibility;
			}
			set
			{
				visibility = value;
			}
		}
		
		/// <summary>
		/// Location property
		/// </summary>
		public System.Drawing.Point Location
		{
			get
			{
				return MyLocation;
			}
			set
			{
				icon.Location = value;
				MyLocation = value;
			}
		}

		/// <summary>
		/// Site of component in Container
		/// </summary>
		private ISite siteName;
		public ISite Site 
		{
			get
			{
				return siteName;
			} 
			set
			{
				siteName = value;
			}
		}


		/// <summary>
		/// called when the Sprite is deleted
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		public virtual void Dispose(object sender, System.EventArgs e)
		{
			
		}

		/// <summary>
		/// called when the Sprite is deleted
		/// </summary>
		public virtual void Dispose(){}
	}

}
