using System;
using System.Threading;

namespace GameDefinitions
{
	/// <summary>
	/// Summary description for AnimationEffect.
	/// </summary>
	public class AnimationEffect
	{

		public int count = 0;
		public Timer tmr;

		public AnimationEffect()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
