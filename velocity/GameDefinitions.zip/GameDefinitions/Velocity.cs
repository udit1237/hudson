using System;

namespace GameDefinitions
{
	/// <summary>
	/// Summary description for Velocity.
	/// </summary>
	public class Velocity
	{
		public Velocity()
		{
			_direction = 0;  // The current direction (0 thru 359 degrees)
			_speed = 0;      // The current speed
			_dx = 0;         // The x-component of speed
			_dy = 0; 
		}

		double sine(int degree) 
		{
			return Math.Sin( ((2.0 * PI) / 360.0) * ((double)degree) );
		}

		double cosine(int degree) 
		{
			return Math.Cos( ((2.0 * PI) / 360.0) * ((double)degree) );
		}

		public Velocity(Speed speed, Direction direction)
		{
			_direction = (direction.getDirection() % 360);
			_speed = speed.getSpeed();
			_dx = ((int)(cosine(direction.getDirection() % 360) * speed.getSpeed()));
			_dy = ((int)(sine(direction.getDirection() % 360) * speed.getSpeed()));
		}

		public void setSpeed( Speed speed) 
		{
			_speed = speed.getSpeed();
			_dx = ((int)(cosine(_direction) * speed.getSpeed()));
			_dy = ((int)(sine(_direction) * speed.getSpeed()));
		}

		public void setDirection(Direction direction) 
		{
			_direction = direction.getDirection() % 360;
			//Console.WriteLine("getting direction "+_direction);
			_dx = (int)(cosine(_direction) * _speed);
			_dy = (int)(sine(_direction) * _speed);
		}

		public Speed getSpeed() 
		{
			return new Speed(_speed);
		}

		public int speedX() 
		{
			return _dx;
		}

		public int speedY() 
		{
			return _dy;
		}

		public Direction getDirection() 
		{
			return new Direction(_direction);
		}

		public bool isHeadingUp() 
		{
			return ( _dy < 0 );
		}

		public bool isHeadingDown() 
		{
			return ( _dy > 0 );
		}

		public bool isHeadingLeft() 
		{
			return ( _dx < 0 );
		}

		public bool isHeadingRight()
		{
			return ( _dx > 0 );
		}

		public void reverse() 
		{
			reverseX();
			reverseY();
		}

		public void reverseX() 
		{
			_dx = -_dx;
			if ( _direction < 180 ) 
			{
				_direction = 180 - _direction;
			}
			else 
			{
				_direction =  (540 - _direction) % 360;
			};
		}

		public void reverseY() 
		{
			_dy = -_dy;
			_direction = (360 - _direction) % 360;
		}

		protected int _direction;  // The current direction (0 thru 359 degrees)
		protected int _speed;      // The current speed
		protected int _dx;         // The x-component of speed
		protected int _dy;         // The y-component of speed

		protected static /*const*/ double PI = 3.14159265;        // Value of pi
	
	}
}
