using System;
using System.Drawing;

namespace GameDefinitions
{
	/// <summary>
	/// Summary description for CompositeMovableSprite.
	/// </summary>
	public abstract class CompositeMovableSprite:MovableSprite
	{
		public CompositeMovableSprite(Point p, Size s):base(p,s)
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
