using System;

namespace GameDefinitions
{
	/// <summary>
	/// Summary description for ContainerEmptyException.
	/// </summary>
	public class ContainerEmptyException:Exception
	{
		public ContainerEmptyException()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
