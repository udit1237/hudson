using System;

namespace GameDefinitions
{
	/// <summary>
	/// Summary description for Direction.
	/// </summary>
	public class Direction
	{
		public Direction()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public Direction(int value)
		{
			_direction = value;
		}

		public int getDirection()
		{
			return _direction;
		}

		protected int _direction;
	}
}
